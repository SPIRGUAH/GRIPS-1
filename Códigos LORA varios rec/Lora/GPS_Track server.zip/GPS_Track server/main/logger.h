#define LOGFILE "/data.log"
#define FLASH_BLOCK_SIZE 4096
#define LINE_SIZE 64

bool logger(char * );