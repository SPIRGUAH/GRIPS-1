// Comment out for NO access controls
#define AccessControl

// Set your server access username and password here (OPTIONAL:)
const char* http_username = "admin";
const char* http_password = "admin";

// Set a server logical name, this gets translated to the physical IP address e.g. http://192.168.0.22
// NOTE: ONLY works if your browser supports this function
const char* ServerName    = "fileserver";

// Set your Wi-Fi Credentials here
//const char* ssid          = "Alifanfaron";
//const char* password      = "MZRSSP_1968";

const char* ssid     = "S2P";     // change this for your own network
//const char* password = "TExY-yAx7-xwMO-Fh6g";  // change this for your own network
const char* password = "PASSWORD";  // change this for your own network